'use strict';

var attachments = {
	confirmProductAttached: function(product_list) {
		return confirm(confirm_text + '\n\n' + product_list);
	}
}
