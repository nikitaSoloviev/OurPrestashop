<?php
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'prestashop');
define('_DB_USER_', 'root');
define('_DB_PASSWD_', 'P@ssw0rd');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', '5pm7fNpXSAWH2P33EndbbbASTH1zXSKGXKJ8X8FoO9MEiaQgaNzWFQNF');
define('_COOKIE_IV_', 'kCkI9ond');
define('_PS_CREATION_DATE_', '2020-11-07');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.1.9');
define('_RIJNDAEL_KEY_', 'ht9jcZ1CDDqwwBFRSayf0PsoJdoTXOTM');
define('_RIJNDAEL_IV_', 'Em2FTEXsKA6bpo4aSp74ng==');
